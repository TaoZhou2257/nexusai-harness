# HANDOFF — 交接摘要（2026-10-07 · 全量重写）

## 一句话现状
NexusAI 桌面插件（`@toby/dsh-plugin-nexusai`）已把登录、能力同步与「专家 · 技能 · 连接器」工作台全部跑通并逐一真机验证：NexusAI 登录替换了 dsh 内置账号 UI（左下角同一位置）、品牌名与来源计数全部接口驱动、技能页含 本地/SkillHub/远程 三来源（本地可启用关闭、SkillHub 可搜索/翻页/看详情/真安装）、连接器已补齐「创建 + 导入」两套 MCP。tsc 0 错误，dsh 基线 0.2.0-rc.2。剩余：agent 实调联调（P2）、导入 MCP 的 SSE 接入方式待拍板。

## 今日进展（2026-10-07）
**工作台（侧栏「专家 · 技能 · 连接器」）**
1. 布局对齐 WorkBuddy 真机：能力标签行右端放搜索框 + `已安装(N)` + `＋添加技能`（技能页常驻）；删掉重复的页面标题行与「精选技能/换一批」行；计数改挂标签（专家 11 / 技能(当前来源) / 连接器 5）
2. 技能来源标签带动态计数：`本地 (21)` / `SkillHub (24，随翻页增长)` / `远程获取 · NexusAgent Builder (1)`；品牌名来自 `GET /v1/base/custom`
3. SkillHub：分类标签改为接口获取（`/api/v1/categories`，13 项含 Pay Skill）、左右箭头翻页、向下无限翻页（去重累积 + 空页判到底 + 「没有更多了」，头部不随滚）；**修复「筛选失效」**（根因=市场 `publicSlug` 不唯一导致 React key 重复、旧节点残留 → 改用 `namespace.canonicalName` 作唯一 id，安装/去重/已安装标记同步改用 id）
4. **技能详情页**（对齐 WorkBuddy 的详情形态）：返回 / 68px 圆图标 / 标题 / 安装或已安装 + 在 SkillHub 打开 / 指标（下载·收藏·安装·评论）/ 元信息 7 行 / 技能介绍（折叠）/ 技能内容（预览=自写轻量 markdown 渲染，源码=等宽原文）/ 更新说明；接口坑：`/api/v1/skills/<canonical>` 会 405，须「裸 slug 进路径 + `?namespace=@handle`」消歧
5. 卡片图标：修「裂图」（接口把缺失图标返回成 JSON `null`，被判成字符串 "null" → `src="null"`）；宿主规范化 + 客户端 `onError` 回落字母头像
6. 标记：需 API Key 的技能名后画**钥匙图标**（橙色，自绘 SVG；数据 `labels.requires_api_key`），详情页另有「需 APIKey / 付费技能」chip（`labels.pricing_type`）；收藏图标由对勾圆圈换成**五角星**
7. **本地标签的启用/关闭**：关闭=把 `SKILL.md` 改名 `SKILL.md.disabled`（注册表自动从「/」目录移除，真生效），启用=改名回来；卡片右侧常显 `[ … ][ 开关 ]`（顺序：更多操作在左、开关在右）；「…」菜单 = 查看技能内容（本地详情）/ 复制技能路径 / 删除技能（二次点击确认，删整个目录）；列表按名称排序，**关闭不改行位置**
8. 体验修复：切换/删除后的后台刷新改为**静默刷新**（占位只在首次加载且列表为空时出现）+ 内容不变不换数组 + 有界轮询 → MutationObserver 实测 0 次闪烁

**能力同步**
9. **连接器补齐「导入 MCP」**：NexusAI 有两套目录——创建 MCP `GET /v1/mcp/server/list`（bff 走 streamable）+ 导入 MCP `GET /v1/mcp/list`（`sseUrl`/`streamableUrl`/`transport`，工具数走 `/v1/mcp/tool/list?mcpId=`）。新增 `src/sync/mcp-list.ts` 统一两套 → 面板显示 5 个（创建 3 + 导入 2，副标题标来源）；可 streamable 的自动写 mcp-client 行，legacy SSE 的展示但标「SSE 未接入」（dsh 只支持 stdio/streamable-http）
10. **修 MCP 行重复堆积 bug**：`mcp-rows.ts` 的 `removeOwnedItems` 用 `Array.isArray` 判断 YAML 节点（`YAMLSeq` 永远不是 JS 数组）→ 旧行从未删除，patch 文件堆到 231 行（77 份重复）；改 `isSeq(insert) && insert.items` 后重启一次收敛为 1 个 insert / 3 行

## 功能形态（当前真实状态，全部真机验证）
- **侧栏一级「专家 · 技能 · 连接器」**：`sidebar.panellist` 图标行 + `main` 键控面板（`NexusaiWorkbench.tsx`）。能力标签行：`专家 (11)` / `技能 (N)` / `连接器 (5)`，技能页右端常驻搜索框 + `已安装(21)` + `＋添加技能`；**未登录时隐藏「专家」以及 技能/连接器 两个「远程获取」来源**，其余照常（见下「未登录形态」）
  - **专家** = NexusAI 自定义工具卡片（首字母头像 + 名称 + 描述）
  - **技能** 三来源：
    - **本地** = 对话「/」菜单同源目录（`remote.skills.list`，与斜杠菜单同一 Remote/过滤）＋ 已关闭项；每卡片：开关（启用/关闭）+「…」（查看技能内容 / 复制路径 / 删除技能-二次确认）；内置技能（无文件）无开关与菜单
    - **SkillHub** = 腾讯市场：搜索 / 14 个分类芯片（左右箭头翻页）/ 无限滚动 / 卡片（图标·名称·单行描述·⚡下载·☆收藏·＋安装或绿色「已安装」）；点卡片进详情（预览|源码）
    - **远程获取 · <品牌>** = NexusAI 目录（下载 SKILL.md 到本地技能根）
  - **连接器** 两来源（同技能页的子选项卡）：**本地** = 本机 profile 里的 mcp-client 行（名称 · transport · url）；**远程获取 · <品牌>** = 创建 MCP + 导入 MCP 卡片（来源 + 工具数；legacy SSE 的带「SSE 未接入」标记）；未登录时远程来源隐藏，本地照常
- **左下角 NexusAI 账号按钮**（`settings.launcher`，priority -1 遮蔽内置，内置行保留作崩溃兜底）：未登录=单击直接开登录弹窗；已登录=头像+用户名 → 菜单（打开设置 / 同步能力 / 登出）
- **登录弹窗**：打开即自动取验证码；动态品牌（`{tab.title}`）；服务器地址（裸 origin + 「应用」按钮：脏值才可点 → 连通性测试转圈 → 通过才持久化）；空字段抖动校验；错误提示在表单下方（不遮输入框）；失败自动重发且**保留密码**；取消=一步关闭
- **设置 → NexusAI 分区**：组织选择器 / 同步 / 登出；未登录显示登录入口
- **内置 DeepSeek 账号 UI 已隐藏**：`cordis.patch.yml` 禁 `ui-settings-account`（客户端行安全；**宿主 `deepseek-account` 行绝不可禁**）

**未登录形态（2026-10-07 末批）**
11. 未登录不再把整个工作台替换成登录门：**隐藏「专家」能力标签**与技能里的**「远程获取」来源**（两者都依赖 NexusAI 账号），其余照常可用——**本地**技能（文件名/开关/删除）与 **SkillHub**（搜索/分类/翻页/详情/安装）都无需登录；**连接器**标签保留但显示「登录后可同步 NexusAI 的 MCP 服务」+ 登录按钮；登出时清空 NexusAI 侧列表（工具/远程技能/连接器），并自动把活动标签、技能来源回落到仍可见的项（技能/本地）；登录弹窗在主区各分支都可打开
  - 真机复验（先备份 `.credentials.yaml` → 通过启动器菜单登出 → 验证 → 恢复凭据重启）：登出态 = 标签 `技能 (21) / 连接器 (0)`（无专家）、来源 `本地 (21) / SkillHub (24)`（无远程获取）、SkillHub 列表 24 张卡可开详情、连接器显示登录提示；恢复后 = 标签 `专家 (11) / 技能 (1) / 连接器 (5)`、来源三项齐全、MCP 行重新写回 3 行

**连接器双来源（2026-10-07 末批）**
12. 连接器与技能同构，分两个来源子选项卡：**本地 (N)** = 本机自己的 mcp-client 行（`McpRowSync.list()` 解析 profile patch，排除插件自己写的 `nexusai-mcp-*` 行），**远程获取 · <品牌> (M)** = NexusAI 两套目录（创建 + 导入）。切来源时能力标签计数跟随（同技能页）；**未登录时远程来源整个隐藏（与技能的「远程获取」一致，不再显示登录提示）**，本地来源照常（纯文件读取）；本地为空时提示「本机还没有配置本地 MCP 服务（可在配置文件里添加 mcp-client 行）」
  - 真机复验：`本地 (0) / 远程获取 · NexusAgent Builder (5)`；临时插入一条 `local-demo-fs` 行后本地标签立刻显示该服务（serverName · transport · url），**测试后已删除该行**（否则 dsh 会去连一个不存在的地址）；patch 文件仍为 3 条 nexusai-mcp 行、无重复

**侧栏图标（2026-10-07 末批）**
13. 侧栏「专家 · 技能 · 连接器」图标由 `IconGlobeOutlineRegular`（地球，不达意）换成**自绘工具箱 SVG**（`client/NexusaiPanelIcon.tsx`：箱体 + 提手 + 箱缝 + 锁扣，1.7 描边、currentColor，随侧栏选中态变色）——意象是「这一格里装着工具/能力」，且与 dsh 自带侧栏图标（插件=风车、工作区=网格）不撞。真机截图确认 16–18px 下清晰可辨

## 架构与关键接缝
| 环节 | 实现 |
|---|---|
| 授权 flow | `NexusaiAuthService` 注册 `ctx.authorization.registerFlow`（key `nexusai/session`）：captcha → 等提交 → bff login → `session.commit(grant)` |
| 尝试状态机 | initializing/waiting-input/verifying/committing/succeeded/cancelled/failed，`@Remote({mode:'stream'}) watch` 下发 |
| 凭据 | flow 唯一提交者（`nexusai/session`）；`nexusai/endpoint` 存 base url 覆盖 |
| 客户端 fiber | mount/consumer 双 fiber：顶层只 inject 基础服务并 `$mount`，消费者用 `ctx.plugin({inject:['remote.nexusaiAuth','remote.nexusaiCapabilities','theme','sessions','remote.skills']})`（避免自锁） |
| 状态共享 | 一条 watch 流 → 共享快照 store → `useNexusai(selector)` 合成 hook |
| 槽位 | `sidebar.panellist` + `main`（键控）+ `settings.launcher`（priority -1）+ `settings.section` |
| Typert Remote | 手写描述符 28 条（`client/remote.ts`）；宿主方法参数名会被 esbuild 按冲突重命名 → 改参数后必须 `grep "async <method>(" lib/index.js` 核对 |

## 文件地图
```
src/                        宿主半
  index.ts                  apply：装配 + inject ['credentials','tools','authorization'] + LocalSkills/SkillHubClient
  config.ts                 插件配置（baseUrl、AES keys、skillhub.apiBase/webBase、skills.downloadRoot…）
  service/auth.ts           登录服务（flow/状态机/watch/品牌/连通测试）+ 登录后能力同步
  service/capabilities.ts   能力 Remote：列表/同步/下载/技能详情预览/本地技能操作
  nexus/api-client.ts       bff 客户端（可变 base、/service/api 前缀、envelope 解码、连通探测、品牌）
  nexus/model.ts            接口类型（含导入 MCP：ImportedMcpServerRow / ImportedMcpToolListResponse）
  nexus/skillhub.ts         SkillHub 客户端（搜索/分类/详情/安装/预览；canonical-id 与 URL 消歧）
  sync/custom-tools.ts      自定义工具 → dsh 工具（OpenAPI → defineTool）
  sync/mcp-list.ts          两套 MCP 目录归一（创建 + 导入；connectable 判定）
  sync/mcp-rows.ts          写/清 `nexusai-mcp-*` insert 行（YAML 保注释 + 原子写）
  sync/local-skills.ts      本地技能启用/关闭（改名）、扫描已关闭、读取与删除（路径守卫）
  sync/{skills,endpoint-store,session-store,openapi}.ts
client/                     浏览器半
  index.ts                  双 fiber + 快照 store + 槽位注册 + controller（ops 透传）
  face.ts                   DTO/inject face/unwrap（含 LocalSkillEntryFace）
  remote.ts                 Typert 描述符（28 条）
  NexusaiWorkbench.tsx      三选项卡工作台（详情页、本地开关菜单、SkillHub 列表/详情、连接器卡片）
  NexusaiSignInDialog.tsx   登录弹窗     NexusaiLauncher.tsx 左下角入口
  NexusaiSection.tsx        设置分区     NexusaiPanelIcon.tsx 侧栏图标
  locales.ts                zh/en 字典
scripts/
  build.mjs                 esbuild 双产物（宿主 ESM / 客户端 CJS + ModuleLoader 包裹）
  check-dsh-version.mjs     dsh 版本基线（npm run check:dsh）
  verify/cdp-eval.mjs       CDP 驱动运行中的桌面端（读 DSH_CDP_PORT，默认 9222）
```

## 换机器 / 新环境部署（2026-10-08）
**结论：dsh 源码零改动即可迁移**——`git status` 在 dsh 检出里是干净的（tag `dsh-v0.2.0-rc.2`），所有 NexusAI 相关的东西都落在三处：① 插件仓库本身 ② 生成的 dev home 里的 profile patch ③ 指向插件的符号链接。已写成幂等安装脚本 `scripts/dev/install-into-dsh.mjs`：

```bash
# 新机器上（Node ^22.19 || ≥24，pnpm 11.7.0）
git clone <dsh 仓库> ~/IdeaProjects/deepseek-harness && cd ~/IdeaProjects/deepseek-harness
git checkout dsh-v0.2.0-rc.2          # 与插件 dshBaseline 对齐
pnpm install
pnpm run start:desktop                # 先跑一次，生成 .desktop-build/development（然后可关掉）
git clone <本插件仓库> ~/GoLandProjects/nexusai-harness
cd ~/GoLandProjects/nexusai-harness
node scripts/dev/install-into-dsh.mjs # 构建 + 建符号链接 + 写 patch 行（幂等，可重复跑）
DSH_DESKTOP_RENDERER_DEBUG_PORT=9223 pnpm --dir ~/IdeaProjects/deepseek-harness run start:desktop
```
- 脚本做四件事：`node scripts/build.mjs` 出 `lib/{index,client}.js`；把插件软链到 `<dsh>/apps/desktop/.desktop-build/development/project/node_modules/@toby/dsh-plugin-nexusai`；在 dev home 的 `profiles/desktop/cordis.patch.yml` 补 `- id: ui-settings-account / disabled: true` 与 `nexusai` 插入行（baseUrl + AES keys，可用 `DSH_BASE_URL` / `AES_KEY` / `AES_IV` 覆盖）；打印后续步骤
- **不需要拷贝**：账号凭据（新机器上登录一次即可，凭据本来就按机器存）、`.desktop-build`（自动生成）、`nexusai-mcp-*` 行（登录后由插件重写）
- **要带走的**：插件仓库（或打包 tar）、baseUrl/AES key/IV 两个值（脚本默认值即当前生产配置）、可选 `scripts/dev/` 下的窗口摆位脚本（需辅助功能权限）
- 迁移后自检：`npm run check:dsh`（版本一致）→ `npx tsc --noEmit` → 启动后侧栏出现「专家 · 技能 · 连接器」→ 登录 → 连接器显示创建+导入 MCP、技能页三来源可用
- ⚠️ 只允许跑**一个** dsh 实例：残留实例会占住 19387（web 端口），新实例启动会以 `DesktopHostFatalError: 2 required plugins did not activate`（根因 `EADDRINUSE 19387`）失败。清理：`pkill -9 -f "Harness Dev.app"; pkill -9 -f dsh-desktop-host; rm -f <dev>/electron-user-data/Singleton*`
### 不装 dsh 源码的路线（体验/试用推荐）
dsh 的**插件管理器（侧栏「插件」页）支持四种安装来源**（源码 `packages/boot/plugin-manager/src/install-spec.ts`：registry 包名 / **本地绝对路径** / **tgz 压缩包（本地或 http）** / git 仓库），装的时候用 pnpm 写进 profile 并补齐依赖——所以新机器只要有一个 **dsh 桌面应用**（打包版）+ 我们的插件包即可：
```bash
# 1) 本机产出 dsh 桌面应用（耗时较长；未签名时新机器首次打开需右键 → 打开）
cd ~/IdeaProjects/deepseek-harness && pnpm run package:desktop:mac:arm64
# 2) 本机产出插件包（147KB，已验证只含 lib/{index,client}.js + package.json）
cd ~/GoLandProjects/nexusai-harness && npm pack        # → toby-dsh-plugin-nexusai-0.1.0.tgz
# 3) 新机器：装好 dsh → 侧栏「插件」页 → 安装 → 填 tgz 绝对路径（或插件仓库的绝对路径）
#    随后在该机器 profile 的 user 层 patch 里补 nexusai 行（baseUrl + AES key/IV）；
#    插件目前未声明配置表单，所以这步需手改 YAML（后续可加配置表单一步到位）
```
- **已验证**：打包产物干净（`files: ["lib","README.md","HANDOFF.md"]`，并删掉了仓库里一个自指符号链接 `nexusai-harness -> 自己`，它会污染打包）；dsh 接受的四种 spec 形式来自其源码
- **未实测**：插件页安装这条链路没在本机跑（本机是 dev 接线，装了会双份加载）；若失败则回到下面的源码路线
- 更远的目标（给**非开发机**做品牌化的自有壳）仍走「产品化」路线（自有 Electron 壳 + 打包管线），见「架构决策」

## 红线与坑（务必遵守）
1. **不改 dsh 源码**；配置只进 dev home 的 `cordis.patch.yml`。**应用运行时会改写该文件**——要手工改先停应用，否则会被覆盖
2. **宿主 `deepseek-account` 行永远不禁用**（欢迎窗 RPC 硬依赖，禁用=启动 fatal）
3. 改 client/src/patch 后必须重启桌面；**不要 Page.reload**（会搞挂宿主）
4. **esbuild 会重命名宿主 Remote 方法的参数**（与外层标识符冲突时）→ Typert 按编译后签名校验，报 `args fields do not match the descriptor`；改参数后核对 `lib/index.js`
5. **React 列表 key 必须唯一**：上游「天然主键」不可想当然（SkillHub 的 `publicSlug` 一页里就有重复，导致替换列表时旧节点残留 → 表现为「筛选失效」）
6. **外部接口空值不能只判 undefined/''**：JSON `null` 与字面量 `"null"` 都出现过（图标裂图）
7. **yaml 库解析结果是节点类型**（`YAMLSeq`/`YAMLMap`），判断集合要用 `isSeq/isMap`，`Array.isArray` 永远 false（曾导致 MCP 行重复堆积 77 份）
8. **注册表对文件变更的响应**：改名（SKILL.md ↔ .disabled）会刷新目录；**删除整个目录不会**——列表另用 `missingLocalSkills(paths)` 按磁盘核对，别指望目录接口
9. **dsh mcp-client 只支持 stdio / streamable-http**：legacy SSE（`event: endpoint` 握手）无法接入
10. 验证码 60s 有效；换 base url 后旧 token 对新服务器无效（401 自动登出）
11. 本机环境：**WorkBuddy 常驻占用 9222** → dsh 用 `DSH_DESKTOP_RENDERER_DEBUG_PORT=9223` 启动，验证脚本读 `DSH_CDP_PORT`；被强杀的实例会留下 `electron-user-data/Singleton*` 导致新实例秒退（删掉即可）；`pkill -9 -f "Harness Dev.app"` + `pkill -9 -f dsh-desktop-host` 清干净再起
12. 截屏看用户的 WorkBuddy 需要 macOS 屏幕录制权限（已开）：`screencapture -x /tmp/x.png` + `osascript -e 'tell application "WorkBuddy" to activate'`
13. typecheck 依赖 `node_modules/@deepseek-ai` symlink → dsh 的 project node_modules（`npm install` 后需重建）；升级 dsh 后跑 `npm run check:dsh` + tsc + CDP 回归并更新 `dshBaseline`

## 桌面窗口位置（启动即居中）
dsh 的窗口在**自己的源码里**创建（`apps/desktop/src/main.ts` `createWindow`：`width:1280, height:820`，**没有 x/y**），dev 启动脚本也不传位置；它既不保存窗口 frame，也没有几何配置（只有 Windows 签名的环境变量）。所以位置由 macOS/Electron 的默认规则决定，实测这台机器（屏幕 1512×982、菜单栏占 34px、工作区 34→908 共 874 高、Dock 顶 ≈908）：
- **原生启动 = (116, 34)**：水平方向**正好居中**（(1512-1280)/2 = 116），垂直方向**贴住工作区顶部**（菜单栏下沿 34）——这就是"居上对齐"的来源
- 原因：窗口高 820 已占工作区 874 的 94%，顶部对齐后底部只剩 ~54px 余量，视觉上非常明显
- （早先另一次测量读到过 (144, 87)，说明 macOS 对无位置窗口偶尔会带一点级联偏移，但"贴顶"是常态）

**不动 dsh 源码的解法**（本仓库内，两个新脚本，启动时自动摆位）：
- 摆位模式（`DSH_WINDOW_PLACEMENT`）：

  | 模式 | 效果 | 实测落点 |
  |---|---|---|
  | `center`（默认） | 工作区内垂直+水平居中 | (116, 61) —— 上下各 27px 留白 |
  | `bottom` | 贴住 Dock | (116, 88) |
  | `keep` | 保持 macOS 默认（贴工作区顶部） | (116, 34) |
- 工作区几何**从应用渲染进程读**（CDP `screen.availTop/availBottom` 等，实测 (0,34) 1512×874），所以菜单栏与 Dock 的占位都被算进去，落点是像素级准确；CDP 不可用时退回 Finder 的全屏 bounds
- 用法：`DSH_WINDOW_PLACEMENT=bottom scripts/dev/start-desktop.sh`；对运行中的窗口也可直接 `node scripts/dev/center-window.mjs --mode center|bottom|keep`，另有 `--top N` 精确指定、`--window "<标题>"` 换目标、`--probe` 只读位置
- **包装脚本支持换启动命令**：`DSH_START_SCRIPT=dev:desktop scripts/dev/start-desktop.sh`（默认 `start:desktop`，`dev:desktop` 会先 build）——用户若习惯 `pnpm run dev:desktop`，用这个就不会漏掉摆位
- **不想改启动习惯**：`scripts/dev/watch-window.sh [center|bottom]` 守候进程——由它盯窗口：每次应用启动、窗口首次出现时摆一次位，之后不再干预（手动拖动不会被抢回；窗口关闭后再次启动会再摆一次）。实测：用 **plain `pnpm run start:desktop`**（不经包装脚本）启动，守候进程日志 `window placed (center)`，窗口落在 (116,61) 工作区正中
- 端口自动发现：脚本会依次尝试 9222/9223/9224/9225/9231 找 `dsh-app` 页面（dsh 的 inspector 端口会变，且 9222 常被 WorkBuddy 占用），因此守候进程无需端口环境变量
- `scripts/dev/center-window.mjs`：用 AppleScript（System Events）摆位（默认工作区居中）；**按窗口标题匹配**而不是进程名——本机同时有 WorkBuddy（process `Electron`，窗口 `WorkDSH`）在跑，按进程名会动错窗口；每次 osascript 调用带 15s 超时（System Events 在应用启动期会挂住）；`--top N` 可改为贴某一行，`--window "<标题>"` 可换目标
- `scripts/dev/start-desktop.sh`：启动桌面端（`DSH_REPO`、`DSH_DESKTOP_RENDERER_DEBUG_PORT` 可覆盖），窗口出现后循环调用上面的单发模式居中（最多 60 次/每次间隔 3s），日志打印 `window centered`
- 迁移要求：移动别的应用的窗口需要**辅助功能（Accessibility）权限**——已确认当前终端可用（早先报 `-1719 not allowed assistive access`，后来可用了）。若权限被关，脚本会打印提示而不会静默失败
- 真机验证：窗口从 (600,200) 被脚本移到 (116,81)（正中）；把窗口故意放到 (500,300) 后跑包装脚本的循环 → 输出 `window centered`、终位 (116,81)；截图确认四周留白均匀
- ⚠️ 探测期间误把 WorkBuddy 的窗口移动过一次（按进程名匹配到了它），已按原位置 (36,34) 还原
- 若要在应用内部彻底解决（持久、免权限），只能改 dsh 源码加 `center: true`（1 行）——违反本项目"不改 dsh 源码"的红线，等用户拍板

## 验证操作手册
```bash
# 起桌面端（注意调试端口，9222 可能被 WorkBuddy 占用）
cd /Users/toby/IdeaProjects/deepseek-harness && DSH_DESKTOP_RENDERER_DEBUG_PORT=9223 pnpm run start:desktop
# 驱动/检查运行中的页面（自动找 dsh-app 目标）
cd /Users/toby/GoLandProjects/nexusai-harness && DSH_CDP_PORT=9223 node scripts/verify/cdp-eval.mjs "<js表达式>"
# 构建与静态检查
node scripts/build.mjs && npx tsc --noEmit && npm run check:dsh
```
查看 patch 行：`~/.desktop-build/development/home/profiles/desktop/cordis.patch.yml`（实际路径 `apps/desktop/.desktop-build/development/home/...`）；凭据：同目录 `.credentials.yaml`（`nexusai/session` = token，`nexusai/endpoint` = base url）。

## 待办
| 优先级 | 任务 | 状态 |
|--------|------|------|
| P1 | **导入 MCP 接入方式待拍板**：① 服务端提供 streamable 端点（我们已支持自动写行）② 插件内实现 SSE MCP 客户端（握手→initialize→tools/list→tools/call）把远端工具注册成 dsh 工具 | ⬜ 等用户决定 |
| P2 | agent 实际调用联调：会话里让 agent 调一个同步来的 custom tool / MCP 工具，验证 schema 与执行链路 | ⬜ |
| P2 | 远程技能下载（NexusAI 目录）实测端到端 | ⬜ |
| 杂 | 「删除技能」是否改为移入废纸篓（当前二次确认后直接删目录） | ⬜ 等用户偏好 |
| 杂 | package.json `types` 指向不存在的 d.ts（补产出或删字段） | ⬜ |
| 可选 | 需要强登录门槛时：shell.overlay 全屏拦截层（未实施） | ⬜ |
| 产品化 | 分发时引入 workdsh 式载体（自有 Electron 壳 + profile 组装 + 打包管线；插件代码零重写，估算 3-5 天）；触发条件 = 要打包 NexusAI 品牌安装包 / 原生层定制 / 脱离官方 dsh 交付 | ⬜ 触发条件未到 |

### 本轮调试留下的清洁项
- 测试用的临时技能（`zz-scratch-skill`、`mm-scratch-skill`、`aa-delete-target`、`zz-bystander`）均已删除；被误删的 `indiv-ebandao-dev-expert` 已从 SkillHub 重新安装
- 代码内无遗留 `TEMP-DEBUG` 日志（已 grep 确认）；`src/sync/mcp-rows.ts` 的重复行已收敛